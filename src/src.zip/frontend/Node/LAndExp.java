package frontend.Node;

public class LAndExp extends Token{
    
    public LAndExp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
