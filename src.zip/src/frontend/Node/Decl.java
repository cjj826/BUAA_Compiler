package frontend.Node;

public class Decl extends Token {
    
    public Decl(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
