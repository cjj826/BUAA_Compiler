package frontend.Node;

public class UnaryOp extends Token{
    
    public UnaryOp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
