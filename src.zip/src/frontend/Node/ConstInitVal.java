package frontend.Node;

public class ConstInitVal extends Token {
    
    public ConstInitVal(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
