package frontend.Node;

public class LOrExp extends Token {
    
    public LOrExp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
