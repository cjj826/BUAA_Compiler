package frontend.Node;

public class BlockItem extends Token {
    
    public BlockItem(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
