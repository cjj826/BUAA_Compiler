package frontend.Node;

public class Cond extends Token{
    
    public Cond(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
