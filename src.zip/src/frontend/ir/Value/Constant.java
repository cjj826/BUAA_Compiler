package frontend.ir.Value;

import frontend.ir.type.Type;

public class Constant extends Value {
    
    public Constant(Type type, String name) {
        super(type, name);
    }
}
