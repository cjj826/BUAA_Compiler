package frontend.ir.Value;

import frontend.ir.type.Type;

public class ZeroInitArray extends Constant {
    
    public ZeroInitArray(Type type, String name) {
        super(type, name);
    }
}
