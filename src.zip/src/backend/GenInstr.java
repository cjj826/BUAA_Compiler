package backend;

public class GenInstr {
    private String res;
    public static int curFuncSpSize;
    
    public String toString() {
        return this.res;
    }
}
