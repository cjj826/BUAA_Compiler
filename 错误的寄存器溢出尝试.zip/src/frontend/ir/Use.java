package frontend.ir;

import frontend.ir.Value.User;
import frontend.ir.Value.Value;

public class Use {
    private Value value;
    private User user;
    private int position;
}
