package backend;

public class GenInstr {
    private String res;
    public static int curFuncSpSize;
    public static int curBlockSp;
    
    public String toString() {
        return this.res;
    }
}
