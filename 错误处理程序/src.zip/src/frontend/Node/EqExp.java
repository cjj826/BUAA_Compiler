package frontend.Node;

public class EqExp extends Token{
    
    public EqExp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
