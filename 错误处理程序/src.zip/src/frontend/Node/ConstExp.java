package frontend.Node;

public class ConstExp extends Token {
    
    public ConstExp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
