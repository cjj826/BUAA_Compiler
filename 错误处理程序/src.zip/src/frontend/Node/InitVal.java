package frontend.Node;

public class InitVal extends Token {
    
    public InitVal(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
