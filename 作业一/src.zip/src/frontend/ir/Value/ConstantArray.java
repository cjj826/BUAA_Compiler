package frontend.ir.Value;

public class ConstantArray {
}
