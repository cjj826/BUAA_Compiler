package frontend.Node;

public class RelExp extends Token{
    
    public RelExp(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
