package frontend.Node;

public class VarDecl extends Token {
    
    public VarDecl(String symbol, String token, int line) {
        super(symbol, token, line);
    }
}
